<?php
date_default_timezone_set('Asia/Taipei');
include("MB_API.php");
$mb = new MB_API();
$start_date = "2016-05-01";
$end_date = "2016-05-10";

$data = $mb->GetClasses(array('Fields'=>array('Classes.Resource'),'StartDateTime'=>date('Y-m-d',strtotime($start_date)), 'EndDateTime'=>date('Y-m-d',strtotime($end_date))));


if(!empty($data['GetClassesResult']['Classes']['Class'])) {
	$classes = $mb->makeNumericArray($data['GetClassesResult']['Classes']['Class']);
	$classes = sortClassesByDate($classes);
	echo '<h3 style="text-align:center">Mindbody class schedule </h3>';
	   foreach($classes as $classDate => $classes) {
		?>

	<center>
	    <table border="2">
		<tr><th colspan="8"> <?php echo $classDate;?></th></tr>
		<tr><th>S.No.</th><th>Class Schedule ID</th><th>Class ID</th><th>Class</th><th>StaffName</th><th>Start Time</th><th>End time</th><th>See Classes</th></tr>
		<?php
		 $counter=0;
		 $counter1 =0;
		
		foreach($classes as $class) {


		    $uniqueId = $class['ID'];
			$sDate = date('m/d/Y', strtotime($class['StartDateTime']));
			$sLoc = $class['Location']['ID'];
			$sTG = $class['ClassDescription']['Program']['ID'];
			$studioid = $class['Location']['SiteID'];
			$sclassid = $class['ClassScheduleID'];
			$sType = -7;
			$linkURL = "https://clients.mindbodyonline.com/ws.asp?sDate={$sDate}&sLoc={$sLoc}&sTG={$sTG}&sType={$sType}&sclassid={$sclassid}&studioid={$studioid}";
			
			$className = $class['ClassDescription']['Name'];
			$startDateTime = date('Y-m-d H:i:s', strtotime($class['StartDateTime']));
			$endDateTime = date('Y-m-d H:i:s', strtotime($class['EndDateTime']));
			$staffName = $class['Staff']['Name']."-".$class['StaffIDs'];

       		?>
			<tr>
			<td><?php  echo $counter;  ?></td>
			<td><?php  echo $sclassid;  ?></td>
			<td><?php  echo $uniqueId;  ?></td>
			    <td><?php  echo "<a href='{$linkURL}'>{$className}</a>"; ?></td>
			    <td><?php  echo $staffName?></td>
			    <td><?php  echo $startDateTime;?></td>
			    <td><?php  echo $endDateTime;?></td>
                <td><?php  echo "<a href='{$linkURL}'>See Schedule</a>"; ?></td>
			 </tr>

			<?php
						$counter=$counter+1;
		}
		?>

		</table>
		</center>
		<br>
		<br>

		<?php
	}
	
} else {
	if(!empty($data['GetClassesResult']['Message'])) {
		echo $data['GetClassesResult']['Message'];
	} else {
		echo "Error getting classes<br />";
		echo '<pre>'.print_r($data,1).'</pre>';
	}
}

function sortClassesByDate($classes = array()) {
	$classesByDate = array();
	foreach($classes as $class) {
		$classDate = date("Y-m-d", strtotime($class['StartDateTime']));
		if(!empty($classesByDate[$classDate])) {
			$classesByDate[$classDate] = array_merge($classesByDate[$classDate], array($class));
		} else {
			$classesByDate[$classDate] = array($class);
		}
	}
	ksort($classesByDate);
	foreach($classesByDate as $classDate => &$classes) {
		usort($classes, function($a, $b) {
			if(strtotime($a['StartDateTime']) == strtotime($b['StartDateTime'])) {
				return 0;
			}
			return $a['StartDateTime'] < $b['StartDateTime'] ? -1 : 1;
		});
	}
	return $classesByDate;
}
?>